
import streamlit as st
import streamlit.components.v1 as components
import html
from pathlib import Path


# =========================================================
# PAGE SETTINGS
# =========================================================

st.set_page_config(
    page_title="MindBloom - Your Magic Message",
    page_icon="✨",
    layout="wide"
)


# =========================================================
# SESSION DATA
# =========================================================

card_number = st.session_state.get(
    "selected_card",
    1
)

message = st.session_state.get(
    "selected_message",
    "A little beautiful thought is waiting for you. 🌸"
)

feeling = st.session_state.get(
    "selected_feeling",
    "your feelings"
)

safe_message = html.escape(str(message))
safe_feeling = html.escape(str(feeling))


# =========================================================
# ASSETS PATH
# =========================================================

BASE_DIR = Path(__file__).resolve().parent.parent
ASSETS_DIR = BASE_DIR / "assets"

# IMPORTANT:
# Your video is named message_girl.mp4
MESSAGE_GIRL_VIDEO = ASSETS_DIR / "message_girl.mp4"


# =========================================================
# BACKGROUND + DESIGN
# =========================================================

st.markdown(
    """
    <style>

    .stApp {
        background:
            radial-gradient(
                circle at center,
                #243c70,
                #10264d,
                #071a38
            );
    }

    .page-title {
        text-align: center;
        color: white;
        font-size: 36px;
        font-weight: bold;
        margin-top: 20px;
    }

    .page-subtitle {
        text-align: center;
        color: #e7a6ff;
        font-size: 18px;
        margin-bottom: 5px;
    }

    .feeling {
        text-align: center;
        color: #ffd6e8;
        font-size: 16px;
        margin-bottom: 15px;
    }

    </style>
    """,
    unsafe_allow_html=True
)


# =========================================================
# HEADER
# =========================================================

st.markdown(
    '<div class="page-title">✨ Your Magic Card ✨</div>',
    unsafe_allow_html=True
)

st.markdown(
    '<div class="page-subtitle">'
    'A little surprise chosen especially for you...'
    '</div>',
    unsafe_allow_html=True
)

st.markdown(
    f'<div class="feeling">'
    f'You were feeling: <b>{safe_feeling}</b>'
    f'</div>',
    unsafe_allow_html=True
)


# =========================================================
# MAIN AREA
# LEFT  = GIRL VIDEO
# RIGHT = CARD + MESSAGE
# =========================================================

left, right = st.columns([1, 2.3])


# =========================================================
# LEFT — MESSAGE GIRL VIDEO
# =========================================================

with left:

    st.markdown("<br><br>", unsafe_allow_html=True)

    if MESSAGE_GIRL_VIDEO.exists():

        st.video(
            str(MESSAGE_GIRL_VIDEO),
            autoplay=True,
            loop=True,
            muted=True
        )

    else:

        st.warning(
            "message_girl.mp4 not found in the assets folder."
        )

    st.markdown(
        """
        <div style="
            text-align:center;
            color:#ffd6e8;
            font-size:15px;
            line-height:1.6;
            margin-top:10px;
        ">
            ✨ Your little message is waiting...<br>
            Take a moment for yourself. 💗
        </div>
        """,
        unsafe_allow_html=True
    )


# =========================================================
# RIGHT — CARD + MESSAGE
# =========================================================

with right:

    card_html = f"""
    <!DOCTYPE html>

    <html>

    <head>

    <meta charset="UTF-8">

    <style>

    * {{
        box-sizing: border-box;
    }}

    body {{

        margin: 0;
        padding: 0;

        background: transparent;

        overflow: hidden;

        font-family: Arial, sans-serif;
    }}


    /* =====================================================
       MAIN AREA
    ===================================================== */

    .magic-area {{

        width: 100%;

        height: 590px;

        display: flex;

        justify-content: center;

        align-items: center;

        position: relative;
    }}


    /* =====================================================
       CARD SCENE
    ===================================================== */

    .scene {{

        width: 300px;

        height: 410px;

        perspective: 1400px;

        position: absolute;

        top: 70px;

        left: 50%;

        transform: translateX(-50%);
    }}


    /* =====================================================
       CARD
    ===================================================== */

    .card {{

        width: 100%;

        height: 100%;

        position: relative;

        transform-style: preserve-3d;

        animation:
            cardEntrance 1.2s ease-out forwards,
            cardTwinkle 1.5s ease-in-out 1.2s 2,
            cardFlip 2s ease-in-out 4.2s forwards,
            cardDisappear 0.8s ease-in 6.2s forwards;
    }}


    /* =====================================================
       CARD ENTRANCE
    ===================================================== */

    @keyframes cardEntrance {{

        0% {{

            opacity: 0;

            transform:
                translateY(100px)
                scale(0.25)
                rotateZ(-12deg);
        }}

        45% {{

            opacity: 1;

            transform:
                translateY(-18px)
                scale(1.10)
                rotateZ(5deg);
        }}

        70% {{

            transform:
                translateY(5px)
                scale(0.96)
                rotateZ(-2deg);
        }}

        100% {{

            opacity: 1;

            transform:
                translateY(0)
                scale(1)
                rotateZ(0deg);
        }}
    }}


    /* =====================================================
       TWINKLING
    ===================================================== */

    @keyframes cardTwinkle {{

        0% {{

            filter:
                brightness(1)
                drop-shadow(
                    0 0 5px
                    rgba(255,255,255,.3)
                );
        }}

        50% {{

            filter:
                brightness(1.9)
                drop-shadow(
                    0 0 20px white
                )
                drop-shadow(
                    0 0 40px #e7a6ff
                )
                drop-shadow(
                    0 0 60px #ffb6e6
                );
        }}

        100% {{

            filter:
                brightness(1.1)
                drop-shadow(
                    0 0 12px #e7a6ff
                );
        }}
    }}


    /* =====================================================
       FLIP
    ===================================================== */

    @keyframes cardFlip {{

        0% {{

            transform:
                rotateY(0deg)
                scale(1);
        }}

        40% {{

            transform:
                rotateY(90deg)
                scale(1.05);
        }}

        70% {{

            transform:
                rotateY(180deg)
                scale(1.05);
        }}

        100% {{

            transform:
                rotateY(180deg)
                scale(1);
        }}
    }}


    /* =====================================================
       CARD DISAPPEARS
    ===================================================== */

    @keyframes cardDisappear {{

        0% {{

            opacity: 1;

            transform:
                rotateY(180deg)
                scale(1);
        }}

        100% {{

            opacity: 0;

            transform:
                rotateY(180deg)
                scale(0.85);
        }}
    }}


    /* =====================================================
       FRONT + BACK
    ===================================================== */

    .front,
    .back {{

        position: absolute;

        width: 100%;

        height: 100%;

        top: 0;

        left: 0;

        border-radius: 28px;

        backface-visibility: hidden;

        -webkit-backface-visibility: hidden;

        display: flex;

        flex-direction: column;

        justify-content: center;

        align-items: center;
    }}


    /* =====================================================
       FRONT CARD
    ===================================================== */

    .front {{

        background:
            linear-gradient(
                145deg,
                #6a2c91,
                #7b3fc6,
                #4361ee,
                #d85b9c
            );

        border:
            4px solid
            rgba(255,255,255,.9);

        box-shadow:

            inset 0 0 35px
            rgba(255,255,255,.25),

            0 18px 45px
            rgba(0,0,0,.45);
    }}


    .sparkle {{

        font-size: 60px;

        margin-bottom: 15px;
    }}


    .card-name {{

        color: white;

        font-size: 25px;

        font-weight: bold;

        text-shadow:
            0 2px 8px
            rgba(0,0,0,.3);
    }}


    .card-hint {{

        color: #ffe7f5;

        font-size: 15px;

        text-align: center;

        margin-top: 15px;

        padding: 0 25px;

        line-height: 1.5;
    }}


    .decorations {{

        font-size: 25px;

        margin-top: 22px;

        letter-spacing: 5px;
    }}


    /* =====================================================
       BACK OF CARD
       COMPLETELY BLANK
    ===================================================== */

    .back {{

        transform: rotateY(180deg);

        background:
            linear-gradient(
                145deg,
                #7b3f98,
                #6b4fc4,
                #536de8
            );

        border:
            4px solid
            rgba(255,255,255,.9);

        box-shadow:

            inset 0 0 40px
            rgba(255,255,255,.25),

            0 18px 45px
            rgba(0,0,0,.45);
    }}


    /* =====================================================
       MESSAGE
       SAME POSITION AS CARD
    ===================================================== */

    .message-box {{

        position: absolute;

        width: 300px;

        min-height: 240px;

        top: 155px;

        left: 50%;

        transform: translateX(-50%);

        opacity: 0;

        animation:
            messageAppear
            0.9s ease-out
            6.7s forwards;

        display: flex;

        flex-direction: column;

        justify-content: center;

        align-items: center;

        text-align: center;

        padding: 30px;
    }}


    @keyframes messageAppear {{

        0% {{

            opacity: 0;

            transform:
                translateX(-50%)
                translateY(25px)
                scale(.9);
        }}

        100% {{

            opacity: 1;

            transform:
                translateX(-50%)
                translateY(0)
                scale(1);
        }}
    }}


    .message-title {{

        color: #e7a6ff;

        font-size: 28px;

        font-weight: bold;

        margin-bottom: 22px;

        text-shadow:
            0 0 12px
            rgba(231,166,255,.5);
    }}


    .message-text {{

        color: white;

        font-size: 20px;

        line-height: 1.7;

        font-weight: 500;

        max-width: 290px;
    }}


    .message-note {{

        color: #ffd6e8;

        font-size: 14px;

        margin-top: 25px;
    }}

    </style>

    </head>


    <body>


    <div class="magic-area">


        <!-- CARD -->

        <div class="scene">

            <div class="card">


                <!-- FRONT -->

                <div class="front">

                    <div class="sparkle">
                        ✨
                    </div>

                    <div class="card-name">
                        Magic Card {card_number}
                    </div>

                    <div class="card-hint">
                        A little surprise is waiting inside...
                    </div>

                    <div class="decorations">
                        🌸 💗 🌸
                    </div>

                </div>


                <!-- BLANK BACK -->

                <div class="back">
                </div>


            </div>

        </div>


        <!-- MESSAGE -->

        <div class="message-box">

            <div class="message-title">
                ✨ Your Message ✨
            </div>

            <div class="message-text">
                {safe_message}
            </div>

            <div class="message-note">
                Keep this little thought with you today 💗
            </div>

        </div>


    </div>


    </body>

    </html>
    """


    # =====================================================
    # DISPLAY ANIMATION
    # =====================================================

    components.html(
        card_html,
        height=610,
        scrolling=False
    )


# =========================================================
# FOOTER
# =========================================================

st.markdown(
    """
    <div style="
        text-align:center;
        color:#e7a6ff;
        font-size:15px;
        margin-top:5px;
    ">
        ✨ Take this little thought with you. ✨
    </div>
    """,
    unsafe_allow_html=True
)


st.markdown("<br>", unsafe_allow_html=True)


# =========================================================
# CHOOSE ANOTHER CARD
# =========================================================

if st.button(
    "🌸 Choose another card",
    use_container_width=True
):

    st.session_state.selected_card = None
    st.session_state.selected_message = None

    st.switch_page(
        "pages/03_support.py"
    )
