
import streamlit as st
from pathlib import Path
import time


# =========================================================
# PAGE SETTINGS
# =========================================================

st.set_page_config(
    page_title="MindBloom - Your Feelings",
    page_icon="🌸",
    layout="wide"
)


# =========================================================
# PATHS
# =========================================================

BASE_DIR = Path(__file__).resolve().parent.parent
ASSETS_DIR = BASE_DIR / "assets"

SUPPORT_VIDEO = ASSETS_DIR / "support_girl.mp4"
GIFT_VIDEO = ASSETS_DIR / "gift_box.mp4"
CARD_GIRL_VIDEO = ASSETS_DIR / "card_girl.mp4"


# =========================================================
# SESSION STATE
# =========================================================

if "stage" not in st.session_state:
    st.session_state.stage = "feeling"

if "selected_feeling" not in st.session_state:
    st.session_state.selected_feeling = None

if "selected_card" not in st.session_state:
    st.session_state.selected_card = None

if "selected_message" not in st.session_state:
    st.session_state.selected_message = None


# =========================================================
# PERSONALIZED MESSAGES
# =========================================================

def create_message(feeling, card_number):

    feeling = str(feeling).lower()

    if "happy" in feeling:
        messages = [
            "Keep this happiness close to you. You deserve moments that make your heart feel light. 🌸",
            "Enjoy this beautiful feeling without overthinking it. 💗",
            "Your happiness matters. Carry this positive energy with you today. ✨"
        ]

    elif "sad" in feeling:
        messages = [
            "It is okay to have a difficult day. Be gentle with yourself today. 🌷",
            "You don't have to solve everything at once. Take things slowly. 💗",
            "A difficult moment does not define your whole story. 🌸"
        ]

    elif "anxious" in feeling:
        messages = [
            "Take one slow breath. You don't have to figure everything out at once. 🌷",
            "Take everything one moment at a time. You are allowed to slow down. 💗",
            "Focus only on your next small step. ✨"
        ]

    elif "exhausted" in feeling:
        messages = [
            "You have been carrying a lot. Give yourself permission to rest. 🌙",
            "Rest is not wasted time. Your mind deserves a pause too. 🌸",
            "You don't have to be productive every moment. Take care of yourself. 💗"
        ]

    elif "overwhelmed" in feeling:
        messages = [
            "Choose just one small thing to handle first. You don't need to do everything at once. 🌷",
            "Pause. Breathe. Take one step, then another. 💗",
            "Focus on the next small step instead of the whole list. ✨"
        ]

    elif "worried" in feeling:
        messages = [
            "Focus on what you can control today and let the rest wait. 🌸",
            "You don't have to predict every outcome. Take the present moment as it comes. 💗",
            "Give your worried mind some breathing space today. 🌷"
        ]

    elif "lonely" in feeling:
        messages = [
            "Your feelings matter. If you can, talk to someone you trust. 💗",
            "Be kind to yourself today. You deserve care and patience. 🌸",
            "Even quiet days have value. Take care of yourself gently. 🌷"
        ]

    elif "frustrated" in feeling:
        messages = [
            "It is okay to step away for a moment and breathe. 🌷",
            "You don't have to react immediately. Give yourself some space. 💗",
            "Progress doesn't have to look perfect. Keep going. ✨"
        ]

    elif "confused" in feeling:
        messages = [
            "You don't need every answer right now. Give yourself time. 🌸",
            "Start with one simple question: what is the next small thing I can do? 💗",
            "Clarity can take time. Be patient with yourself. 🌷"
        ]

    elif "peaceful" in feeling:
        messages = [
            "Hold onto this peaceful moment. You deserve calm. 🌸",
            "Enjoy this calm feeling without rushing to the next thing. 💗",
            "Let yourself enjoy this quiet moment. ✨"
        ]

    elif "motivated" in feeling:
        messages = [
            "Take the next meaningful step. You don't have to do everything today. 🌸",
            "Turn your motivation into one small action and keep going. 💗",
            "Every small step counts. Believe in your progress. ✨"
        ]

    else:
        messages = [
            "Take things one step at a time. You are doing your best. 🌸",
            "Be patient with yourself today. 💗",
            "Take a breath and give yourself a little kindness. 🌷"
        ]

    return messages[card_number - 1]


# =========================================================
# BACKGROUND
# =========================================================

st.markdown(
    """
    <style>

    .stApp {
        background: linear-gradient(
            135deg,
            #071a38,
            #102d5c
        );
    }

    .main-title {
        color: white;
        text-align: center;
        font-size: 38px;
        font-weight: bold;
    }

    .subtitle {
        color: #e7a6ff;
        text-align: center;
        font-size: 18px;
    }

    .character-text {
        color: #ffd6e8;
        text-align: center;
        font-size: 15px;
        line-height: 1.6;
    }

    </style>
    """,
    unsafe_allow_html=True
)


# =========================================================
# HEADER
# =========================================================

st.markdown(
    '<div class="main-title">🌸 Your MindBloom Space</div>',
    unsafe_allow_html=True
)

st.markdown(
    '<div class="subtitle">'
    'A little place to pause, breathe and take care of yourself 💗'
    '</div>',
    unsafe_allow_html=True
)


# =========================================================
# STAGE 1 — FEELING
# =========================================================

if st.session_state.stage == "feeling":

    left, right = st.columns([1, 2])

    with left:

        st.markdown("<br><br>", unsafe_allow_html=True)

        if SUPPORT_VIDEO.exists():

            st.video(
                str(SUPPORT_VIDEO),
                autoplay=True,
                loop=True,
                muted=True
            )

        st.markdown(
            """
            <div class="character-text">
                I'm here to listen. 🌷<br><br>
                Just tell me how you're feeling.
            </div>
            """,
            unsafe_allow_html=True
        )

    with right:

        st.subheader("💭 How are you feeling right now?")

        st.write(
            "There is no right or wrong answer. "
            "Choose the feeling closest to you. 💗"
        )

        feelings = [
            "😊 Happy",
            "😔 Sad",
            "😰 Anxious",
            "😴 Exhausted",
            "😵‍💫 Overwhelmed",
            "😟 Worried",
            "😐 Okay",
            "💭 Confused",
            "💔 Lonely",
            "😤 Frustrated",
            "🌸 Peaceful",
            "💪 Motivated"
        ]

        for row_start in range(0, len(feelings), 3):

            cols = st.columns(3)

            for i, feeling in enumerate(
                feelings[row_start:row_start + 3]
            ):

                with cols[i]:

                    if st.button(
                        feeling,
                        key=f"feeling_{row_start}_{i}",
                        use_container_width=True
                    ):

                        st.session_state.selected_feeling = feeling
                        st.session_state.selected_card = None
                        st.session_state.selected_message = None
                        st.session_state.stage = "gift"

                        st.rerun()

        st.write("")

        custom_feeling = st.text_input(
            "✍️ Or describe your feeling"
        )

        if custom_feeling.strip():

            st.session_state.selected_feeling = custom_feeling
            st.session_state.selected_card = None
            st.session_state.selected_message = None
            st.session_state.stage = "gift"

            st.rerun()


# =========================================================
# STAGE 2 — FULL SCREEN VIDEO
# =========================================================

elif st.session_state.stage == "gift":

    st.title("🎁 A Little Surprise For You")

    st.markdown(
        """
        <div style="
            text-align:center;
            color:#e7a6ff;
            font-size:18px;
        ">
            Something special is waiting for you... ✨
        </div>
        """,
        unsafe_allow_html=True
    )

    st.write("")

    if GIFT_VIDEO.exists():

        st.video(
            str(GIFT_VIDEO),
            autoplay=True,
            loop=False,
            muted=True
        )

    else:

        st.error("gift_box.mp4 not found.")

    st.write("")

    st.markdown(
        """
        <div style="
            text-align:center;
            color:#ffd6e8;
            font-size:17px;
        ">
            🌷 Your surprise is getting ready... 💗
        </div>
        """,
        unsafe_allow_html=True
    )

    time.sleep(10)

    st.session_state.stage = "cards"

    st.rerun()

# =========================================================
# STAGE 3 — THREE MAGIC CARDS
# =========================================================

elif st.session_state.stage == "cards":

    # -----------------------------------------------------
    # CARD PAGE DESIGN
    # -----------------------------------------------------

    st.markdown(
        """
        <style>

        /* CARD SELECTION BUTTONS */

        div.stButton > button {
            width: 100%;
            height: 260px;

            border-radius: 28px;
            border: 3px solid rgba(255,255,255,0.75);

            color: white;
            font-size: 24px;
            font-weight: 700;

            box-shadow:
                0 12px 30px rgba(0,0,0,0.35),
                inset 0 0 25px rgba(255,255,255,0.12);

            transition:
                transform 0.25s ease,
                box-shadow 0.25s ease,
                border-color 0.25s ease;

            white-space: pre-line;
        }


        /* HOVER EFFECT */

        div.stButton > button:hover {
            transform: translateY(-10px) scale(1.03);

            border-color: white;

            box-shadow:
                0 18px 40px rgba(231,166,255,0.55),
                0 0 25px rgba(255,255,255,0.25);
        }


        div.stButton > button:active {
            transform: scale(0.97);
        }


        /* CARD 1 */

        .card-one button {
            background:
                linear-gradient(
                    145deg,
                    #6a0dad,
                    #9b4dca,
                    #c77dff
                ) !important;
        }


        /* CARD 2 */

        .card-two button {
            background:
                linear-gradient(
                    145deg,
                    #4361ee,
                    #5e60ce,
                    #7b2cbf
                ) !important;
        }


        /* CARD 3 */

        .card-three button {
            background:
                linear-gradient(
                    145deg,
                    #b5179e,
                    #e75480,
                    #ff8fab
                ) !important;
        }


        /* TITLE */

        .cards-title {
            color: white;
            text-align: center;
            font-size: 36px;
            font-weight: 800;
            margin-top: 10px;
        }


        /* SUBTITLE */

        .cards-subtitle {
            color: #e7a6ff;
            text-align: center;
            font-size: 18px;
            margin-bottom: 25px;
        }


        /* GIRL MESSAGE */

        .girl-message {
            color: #ffd6e8;
            text-align: center;
            font-size: 16px;
            line-height: 1.7;
            margin-top: 12px;
        }


        </style>
        """,
        unsafe_allow_html=True
    )


    # -----------------------------------------------------
    # PAGE TITLE
    # -----------------------------------------------------

    st.markdown(
        '<div class="cards-title">'
        '✨ Choose Your Magic Card ✨'
        '</div>',
        unsafe_allow_html=True
    )


    st.markdown(
        '<div class="cards-subtitle">'
        'One little message is waiting for you... 💗'
        '</div>',
        unsafe_allow_html=True
    )


    st.write("")


    # -----------------------------------------------------
    # LEFT VIDEO + RIGHT CARDS
    # -----------------------------------------------------

    left, right = st.columns(
        [1, 2.5],
        gap="large"
    )


    # =====================================================
    # LEFT SIDE — LITTLE GIRL VIDEO
    # =====================================================

    with left:

        st.markdown("<br>", unsafe_allow_html=True)


        if CARD_GIRL_VIDEO.exists():

            st.video(
                str(CARD_GIRL_VIDEO),
                autoplay=True,
                loop=True,
                muted=True
            )

        else:

            st.warning(
                "card_girl.mp4 not found in assets folder."
            )


        st.markdown(
            '<div class="girl-message">'
            '🌸 Pick one card for yourself.<br><br>'
            '✨ Your little message is waiting inside...<br><br>'
            '💗 Choose the one that catches your eye.'
            '</div>',
            unsafe_allow_html=True
        )


    # =====================================================
    # RIGHT SIDE — THREE BEAUTIFUL CARDS
    # =====================================================

    with right:

        card1, card2, card3 = st.columns(3, gap="medium")


        # -------------------------------------------------
        # CARD 1
        # -------------------------------------------------

        with card1:

            st.markdown(
                '<div class="card-one">',
                unsafe_allow_html=True
            )


            if st.button(
                "✨\n\nMAGIC CARD 1\n\n🌸",
                key="magic_card_1",
                use_container_width=True
            ):

                st.session_state.selected_card = 1

                st.session_state.selected_message = create_message(
                    st.session_state.selected_feeling,
                    1
                )

                st.switch_page(
                    "pages/04_magic_card.py"
                )


            st.markdown(
                '</div>',
                unsafe_allow_html=True
            )


        # -------------------------------------------------
        # CARD 2
        # -------------------------------------------------

        with card2:

            st.markdown(
                '<div class="card-two">',
                unsafe_allow_html=True
            )


            if st.button(
                "🌙\n\nMAGIC CARD 2\n\n💫",
                key="magic_card_2",
                use_container_width=True
            ):

                st.session_state.selected_card = 2

                st.session_state.selected_message = create_message(
                    st.session_state.selected_feeling,
                    2
                )

                st.switch_page(
                    "pages/04_magic_card.py"
                )


            st.markdown(
                '</div>',
                unsafe_allow_html=True
            )


        # -------------------------------------------------
        # CARD 3
        # -------------------------------------------------

        with card3:

            st.markdown(
                '<div class="card-three">',
                unsafe_allow_html=True
            )


            if st.button(
                "💗\n\nMAGIC CARD 3\n\n🌷",
                key="magic_card_3",
                use_container_width=True
            ):

                st.session_state.selected_card = 3

                st.session_state.selected_message = create_message(
                    st.session_state.selected_feeling,
                    3
                )

                st.switch_page(
                    "pages/04_magic_card.py"
                )


            st.markdown(
                '</div>',
                unsafe_allow_html=True
            )