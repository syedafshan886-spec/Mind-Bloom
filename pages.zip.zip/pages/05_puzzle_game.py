import streamlit as st
from pathlib import Path
from PIL import Image
import random


# =========================================================
# PAGE SETTINGS
# =========================================================

st.set_page_config(
    page_title="MindBloom - Puzzle Game",
    page_icon="🧩",
    layout="wide"
)


# =========================================================
# PATHS
# =========================================================

# 05_puzzle_game.py is inside:
# app/pages/05_puzzle_game.py

BASE_DIR = Path(__file__).resolve().parent.parent
ASSETS_DIR = BASE_DIR / "assets"

# -----------------------------------------------------
# 5 PUZZLE IMAGES — THEY WILL CYCLE THROUGH IN RANDOM
# ORDER WITHOUT REPEATING, UNTIL ALL 5 HAVE BEEN SHOWN,
# THEN RESHUFFLE FOR THE NEXT ROUND.
# -----------------------------------------------------

PUZZLE_IMAGE_FILENAMES = [
    "puzzle_1.jpg",
    "puzzle_2.jpg",
    "puzzle_3.jpg",
    "puzzle_4.jpg",
    "puzzle_5.jpg"
]

PUZZLE_IMAGES = [
    ASSETS_DIR / filename
    for filename in PUZZLE_IMAGE_FILENAMES
]

CELEBRATION_VIDEO = ASSETS_DIR / "puzzle_celebration.mp4"


# =========================================================
# PUZZLE SETTINGS
# =========================================================

GRID_SIZE = 3  # 3x3 = 9 pieces
TOTAL_PIECES = GRID_SIZE * GRID_SIZE


# =========================================================
# VARYING QUOTES — CHOSEN BY THE USER'S FEELING
# =========================================================
# This mirrors the create_message() logic in 03_support.py
# so the puzzle reward text is not the same for every user.
# Feel free to edit, add, or reword any of these quotes.
# =========================================================

def get_peaceful_quote(feeling):

    feeling = str(feeling).lower()

    if "happy" in feeling:
        quotes = [
            "\"Joy grows brighter when you let yourself sit with it a little longer.\" 🌸",
            "\"You deserve every bit of this lightness you feel today.\" 💗",
            "\"Let this happiness remind you how far you've come.\" ✨"
        ]

    elif "sad" in feeling:
        quotes = [
            "\"Soft days deserve soft care. You are allowed to rest here.\" 🌷",
            "\"Even quiet, heavy days pass. You are not alone in this.\" 💗",
            "\"Healing is not a straight line, and that is okay.\" 🌸"
        ]

    elif "anxious" in feeling:
        quotes = [
            "\"One breath at a time is enough. You don't have to rush.\" 🌷",
            "\"Your calm is closer than it feels. Keep breathing gently.\" 💗",
            "\"This moment is safe. Let your shoulders soften.\" ✨"
        ]

    elif "exhausted" in feeling:
        quotes = [
            "\"Rest is not a reward you earn — it is something you deserve.\" 🌙",
            "\"You have carried enough today. Let yourself pause.\" 🌸",
            "\"Slowing down is not falling behind.\" 💗"
        ]

    elif "overwhelmed" in feeling:
        quotes = [
            "\"You don't have to hold it all at once. Put some of it down.\" 🌷",
            "\"One small piece at a time is still real progress.\" 💗",
            "\"Breathe. The list can wait a little longer.\" ✨"
        ]

    elif "worried" in feeling:
        quotes = [
            "\"Not every worry needs an answer today.\" 🌸",
            "\"Let today be about this moment, not every possible outcome.\" 💗",
            "\"Your mind deserves a little quiet too.\" 🌷"
        ]

    elif "lonely" in feeling:
        quotes = [
            "\"You matter, even in the quiet moments.\" 💗",
            "\"Reaching out is a strength, not a weakness.\" 🌸",
            "\"Gentle company can start with being gentle with yourself.\" 🌷"
        ]

    elif "frustrated" in feeling:
        quotes = [
            "\"It's okay to step back before stepping forward again.\" 🌷",
            "\"Progress rarely feels smooth. Keep going anyway.\" 💗",
            "\"You are allowed to feel this and still be okay.\" ✨"
        ]

    elif "confused" in feeling:
        quotes = [
            "\"Clarity often arrives slowly. Be patient with yourself.\" 🌸",
            "\"You don't need every answer today, just the next small step.\" 💗",
            "\"Uncertainty is not the same as being lost.\" 🌷"
        ]

    elif "peaceful" in feeling:
        quotes = [
            "\"Let this calm settle into you a little deeper.\" 🌸",
            "\"Peace like this is worth pausing for.\" 💗",
            "\"You found this stillness — let yourself enjoy it.\" ✨"
        ]

    elif "motivated" in feeling:
        quotes = [
            "\"Let this energy guide you gently, not push you too fast.\" 🌸",
            "\"Small steady steps built on motivation go far.\" 💗",
            "\"You are capable of more than you realize.\" ✨"
        ]

    else:
        quotes = [
            "\"Peace begins with a deep breath and a gentle mind.\" 🌸",
            "\"You did not have to solve everything today — just this puzzle.\" 💗",
            "\"Small, quiet moments like this one matter.\" 🌷"
        ]

    return random.choice(quotes)


# =========================================================
# STYLE
# =========================================================

st.markdown(
    """
    <style>

    .stApp {
        background: linear-gradient(
            135deg,
            #071a38,
            #102d5c
        );
    }

    .puzzle-title {
        color: white;
        text-align: center;
        font-size: 38px;
        font-weight: bold;
    }

    .puzzle-subtitle {
        color: #e7a6ff;
        text-align: center;
        font-size: 18px;
        margin-bottom: 10px;
    }

    .puzzle-instructions {
        color: #ffd6e8;
        text-align: center;
        font-size: 15px;
        margin-bottom: 25px;
    }

    .bloom-title {
        color: white;
        text-align: center;
        font-size: 40px;
        font-weight: bold;
        animation: bloomPop 1s ease-out;
    }

    .bloom-quote {
        color: #ffd6e8;
        text-align: center;
        font-size: 22px;
        line-height: 1.7;
        max-width: 700px;
        margin: 20px auto;
        animation: bloomFadeIn 1.6s ease-out;
    }

    @keyframes bloomPop {
        0% {
            opacity: 0;
            transform: scale(0.5);
        }
        60% {
            opacity: 1;
            transform: scale(1.1);
        }
        100% {
            opacity: 1;
            transform: scale(1);
        }
    }

    @keyframes bloomFadeIn {
        0% {
            opacity: 0;
            transform: translateY(20px);
        }
        100% {
            opacity: 1;
            transform: translateY(0);
        }
    }

    div.stButton > button {
        border-radius: 14px;
        border: 3px solid rgba(255,255,255,0.4);
        transition: border-color 0.2s ease, transform 0.15s ease;
    }

    div.stButton > button:hover {
        border-color: #e7a6ff;
        transform: scale(1.03);
    }

    </style>
    """,
    unsafe_allow_html=True
)


# =========================================================
# HEADER
# =========================================================

st.markdown(
    '<div class="puzzle-title">🧩 A Little Puzzle For You</div>',
    unsafe_allow_html=True
)

st.markdown(
    '<div class="puzzle-subtitle">'
    'Piece it back together, one gentle click at a time 💗'
    '</div>',
    unsafe_allow_html=True
)

st.markdown(
    '<div class="puzzle-instructions">'
    'Click a piece, then click another piece to swap them. '
    'Rebuild the picture to reveal your surprise. 🌸'
    '</div>',
    unsafe_allow_html=True
)


# =========================================================
# CHECK AT LEAST ONE PUZZLE IMAGE EXISTS
# =========================================================

available_images = [
    path for path in PUZZLE_IMAGES if path.exists()
]

if not available_images:

    st.error(
        "No puzzle images were found in the assets folder. "
        "Please add puzzle_1.jpg through puzzle_5.jpg there "
        "(or update PUZZLE_IMAGE_FILENAMES in the code)."
    )

    st.stop()


# =========================================================
# SESSION STATE
# =========================================================

if "puzzle_order" not in st.session_state:
    st.session_state.puzzle_order = None

if "selected_tile" not in st.session_state:
    st.session_state.selected_tile = None

if "puzzle_solved" not in st.session_state:
    st.session_state.puzzle_solved = False

if "puzzle_quote" not in st.session_state:
    st.session_state.puzzle_quote = None

if "puzzle_image_path" not in st.session_state:
    st.session_state.puzzle_image_path = None

# Queue of images still left to show in the current round,
# so all images appear once before any repeats happen
if "puzzle_image_queue" not in st.session_state:
    st.session_state.puzzle_image_queue = []


# =========================================================
# LOAD + SLICE IMAGE INTO TILES (CACHED PER IMAGE PATH)
# =========================================================

@st.cache_resource
def load_and_slice_image(image_path, grid_size):

    original = Image.open(image_path).convert("RGB")

    # Crop to a square first so tiles line up evenly
    width, height = original.size
    side = min(width, height)

    left = (width - side) // 2
    top = (height - side) // 2

    square_image = original.crop(
        (left, top, left + side, top + side)
    )

    # Resize to a clean multiple of grid_size
    canvas_size = 600
    square_image = square_image.resize(
        (canvas_size, canvas_size)
    )

    piece_size = canvas_size // grid_size

    pieces = []

    for row in range(grid_size):

        for col in range(grid_size):

            piece = square_image.crop(
                (
                    col * piece_size,
                    row * piece_size,
                    (col + 1) * piece_size,
                    (row + 1) * piece_size
                )
            )

            pieces.append(piece)

    return pieces


# =========================================================
# PICK NEXT IMAGE WITHOUT REPEATING
# =========================================================

def get_next_puzzle_image():

    previous_image = st.session_state.puzzle_image_path

    # Refill and reshuffle the queue whenever it runs out
    if not st.session_state.puzzle_image_queue:

        new_queue = available_images.copy()
        random.shuffle(new_queue)

        # Avoid showing the same image twice in a row,
        # even across a queue refill (e.g. only 1 image
        # remained, matched the previous one)
        if (
            len(new_queue) > 1
            and new_queue[0] == previous_image
        ):

            new_queue[0], new_queue[1] = (
                new_queue[1],
                new_queue[0]
            )

        st.session_state.puzzle_image_queue = new_queue

    return st.session_state.puzzle_image_queue.pop(0)


# =========================================================
# INITIALIZE / SHUFFLE PUZZLE ORDER
# =========================================================

def shuffle_puzzle():

    order = list(range(TOTAL_PIECES))

    # Keep shuffling until it is not already solved
    while True:

        random.shuffle(order)

        if order != list(range(TOTAL_PIECES)):
            break

    st.session_state.puzzle_order = order
    st.session_state.selected_tile = None
    st.session_state.puzzle_solved = False

    # Pick the next image from the no-repeat queue
    st.session_state.puzzle_image_path = get_next_puzzle_image()

    # Pick a fresh quote each time the puzzle restarts,
    # based on the feeling the user selected earlier
    # (falls back to a generic peaceful quote if none exists)
    feeling = st.session_state.get(
        "selected_feeling",
        "peaceful"
    )

    st.session_state.puzzle_quote = get_peaceful_quote(feeling)


if st.session_state.puzzle_order is None:
    shuffle_puzzle()


current_image_path = st.session_state.puzzle_image_path

puzzle_pieces = load_and_slice_image(
    current_image_path,
    GRID_SIZE
)


# =========================================================
# SWAP LOGIC
# =========================================================

def handle_tile_click(position):

    if st.session_state.puzzle_solved:
        return

    if st.session_state.selected_tile is None:

        st.session_state.selected_tile = position

    elif st.session_state.selected_tile == position:

        # Clicked the same tile twice — deselect it
        st.session_state.selected_tile = None

    else:

        first = st.session_state.selected_tile
        second = position

        order = st.session_state.puzzle_order

        order[first], order[second] = order[second], order[first]

        st.session_state.puzzle_order = order
        st.session_state.selected_tile = None

        if order == list(range(TOTAL_PIECES)):
            st.session_state.puzzle_solved = True


# =========================================================
# PUZZLE SOLVED — CELEBRATION VIEW
# =========================================================

if st.session_state.puzzle_solved:

    st.balloons()

    left, right = st.columns([1.2, 1.8])

    with left:

        st.markdown("<br>", unsafe_allow_html=True)

        if CELEBRATION_VIDEO.exists():

            st.video(
                str(CELEBRATION_VIDEO),
                autoplay=True,
                loop=True,
                muted=True
            )

        else:

            st.info(
                "🌸 Add puzzle_celebration.mp4 to the assets "
                "folder to show a celebration video here."
            )

    with right:

        st.markdown(
            '<div class="bloom-title">🌼 You Did It! 🌼</div>',
            unsafe_allow_html=True
        )

        st.image(
            current_image_path.as_posix(),
            use_container_width=True
        )

        st.markdown(
            f'<div class="bloom-quote">{st.session_state.puzzle_quote}</div>',
            unsafe_allow_html=True
        )

        st.write("")

        if st.button(
            "🧩 Play Again",
            use_container_width=True
        ):

            shuffle_puzzle()
            st.rerun()


# =========================================================
# PUZZLE IN PROGRESS — GRID VIEW
# =========================================================

else:

    st.write("")

    for row in range(GRID_SIZE):

        cols = st.columns(GRID_SIZE)

        for col in range(GRID_SIZE):

            position = row * GRID_SIZE + col

            piece_index = st.session_state.puzzle_order[position]

            with cols[col]:

                st.image(
                    puzzle_pieces[piece_index],
                    use_container_width=True
                )

                is_selected = (
                    st.session_state.selected_tile == position
                )

                button_label = (
                    "✨ Selected" if is_selected else "Select"
                )

                if st.button(
                    button_label,
                    key=f"tile_{position}",
                    use_container_width=True
                ):

                    handle_tile_click(position)
                    st.rerun()

    st.write("")

    if st.button(
        "🔄 Shuffle Again",
        use_container_width=True
    ):

        shuffle_puzzle()
        st.rerun()