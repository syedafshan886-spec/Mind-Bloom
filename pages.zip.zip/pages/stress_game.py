import streamlit as st
import streamlit.components.v1 as components
from pathlib import Path
import base64
import random
import json


# =========================================================
# PAGE SETTINGS
# =========================================================

st.set_page_config(
    page_title="MindBloom - Stress Garden",
    page_icon="🌸",
    layout="wide"
)


# =========================================================
# IMAGE PATHS
# =========================================================

BASE_DIR = Path(__file__).resolve().parent
ASSETS_DIR = BASE_DIR / "assets"

DRY_GARDEN = ASSETS_DIR / "dry_garden.png"
BLOOM_GARDEN = ASSETS_DIR / "bloom_garden.png"


# =========================================================
# CHECK IMAGES
# =========================================================

if not DRY_GARDEN.exists():
    st.error("Could not find dry_garden.png inside pages/assets/")
    st.stop()

if not BLOOM_GARDEN.exists():
    st.error("Could not find bloom_garden.png inside pages/assets/")
    st.stop()


# =========================================================
# CONVERT IMAGES TO BASE64
# This allows the garden images to work inside components.html
# =========================================================

def image_to_base64(path):
    with open(path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode("utf-8")


dry_image = image_to_base64(DRY_GARDEN)
bloom_image = image_to_base64(BLOOM_GARDEN)


# =========================================================
# DIFFERENT THOUGHT SETS
# =========================================================

thought_sets = [

    [
        "I keep thinking about things I cannot control.",
        "I feel pressured to be perfect.",
        "I have too many things to remember.",
        "I worry about what people think of me.",
        "I am scared I will not do well.",
        "I wish I could stop overthinking."
    ],

    [
        "I have so much work to finish.",
        "I feel like I am falling behind.",
        "My mind keeps replaying everything.",
        "I am worried about my future.",
        "I need to do everything perfectly.",
        "I cannot stop thinking about tomorrow."
    ],

    [
        "I feel tired from trying so hard.",
        "I keep worrying about my studies.",
        "I compare myself with other people.",
        "I feel like everything is too much.",
        "I am afraid of making mistakes.",
        "I keep thinking about the same problem."
    ],

    [
        "What if I disappoint everyone?",
        "I have too many expectations around me.",
        "I cannot switch my mind off.",
        "I worry that I am not doing enough.",
        "I feel nervous about what comes next.",
        "I keep thinking about things I should have done."
    ],

    [
        "I am carrying too many responsibilities.",
        "I keep worrying about my results.",
        "I feel like I need to catch up.",
        "I am afraid that I will fail.",
        "I think too much before making decisions.",
        "I need a break from everything."
    ],

    [
        "I worry about things before they happen.",
        "I feel overwhelmed by my routine.",
        "I keep replaying conversations in my head.",
        "I feel pressure to succeed.",
        "I am scared of making the wrong choice.",
        "I want my mind to feel quieter."
    ]
]


# =========================================================
# SELECT RANDOM THOUGHT SET
# =========================================================

selected_thoughts = random.choice(thought_sets)

thoughts_json = json.dumps(selected_thoughts)


# =========================================================
# HTML GAME
# =========================================================

game_html = f"""
<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>

* {{
    box-sizing: border-box;
}}

html,
body {{
    margin: 0;
    padding: 0;
    width: 100%;
    min-height: 100%;
    font-family: Arial, Helvetica, sans-serif;
    background: transparent;
}}

body {{
    overflow: hidden;
}}


/* =====================================================
   MAIN GAME
===================================================== */

.game-wrapper {{
    width: 100%;
    max-width: 1250px;
    margin: auto;
    padding: 10px;
}}

.game-title {{
    text-align: center;
    color: white;
    font-size: 34px;
    font-weight: 700;
    margin-bottom: 5px;
}}

.game-subtitle {{
    text-align: center;
    color: #f4d9ef;
    font-size: 16px;
    margin-bottom: 12px;
}}

.progress-area {{
    width: 100%;
    max-width: 600px;
    margin: 0 auto 12px auto;
    text-align: center;
}}

.progress-text {{
    color: white;
    font-size: 14px;
    margin-bottom: 6px;
}}

.progress-track {{
    width: 100%;
    height: 8px;
    background: rgba(255,255,255,0.20);
    border-radius: 20px;
    overflow: hidden;
}}

.progress-fill {{
    width: 0%;
    height: 100%;
    background: linear-gradient(
        90deg,
        #d9a7ff,
        #ffb5dc,
        #fff0a8
    );
    border-radius: 20px;
    transition: width 0.7s ease;
}}


/* =====================================================
   GARDEN
===================================================== */

.garden {{
    position: relative;
    width: 100%;
    height: 650px;
    overflow: hidden;
    border-radius: 26px;

    background: #283d2c;

    box-shadow:
        0 20px 60px rgba(0,0,0,0.45);

    border: 3px solid rgba(255,255,255,0.45);
}}


/* Dry garden image */

.garden-dry,
.garden-bloom {{
    position: absolute;
    inset: 0;

    width: 100%;
    height: 100%;

    object-fit: cover;

    transition:
        opacity 1.8s ease,
        filter 1.8s ease,
        transform 1.8s ease;
}}

.garden-dry {{
    opacity: 1;
    filter:
        brightness(0.78)
        saturate(0.55);
    z-index: 1;
}}

.garden-bloom {{
    opacity: 0;
    filter:
        brightness(1)
        saturate(1.15);
    z-index: 2;
}}


/* =====================================================
   PEACEFUL GLOW
===================================================== */

.garden-glow {{
    position: absolute;
    inset: 0;

    z-index: 3;

    pointer-events: none;

    background:
        radial-gradient(
            circle at 50% 45%,
            rgba(255,240,190,0.0),
            rgba(255,230,170,0.0),
            rgba(255,255,255,0.0)
        );

    opacity: 0;

    transition:
        opacity 1.5s ease;
}}

.garden.glowing .garden-glow {{
    opacity: 0.45;

    background:
        radial-gradient(
            circle at 50% 45%,
            rgba(255,245,205,0.32),
            rgba(255,230,190,0.12),
            rgba(255,255,255,0)
        );
}}


/* =====================================================
   THOUGHTS
===================================================== */

.thought {{
    position: absolute;

    z-index: 20;

    width: 190px;
    min-height: 72px;

    padding: 14px 17px;

    display: flex;
    align-items: center;
    justify-content: center;

    text-align: center;

    color: #30253c;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,0.97),
            rgba(246,239,252,0.97)
        );

    border: 2px solid rgba(255,255,255,0.9);

    border-radius: 20px;

    box-shadow:
        0 8px 22px rgba(0,0,0,0.28);

    font-size: 15px;
    font-weight: 600;
    line-height: 1.35;

    cursor: grab;

    user-select: none;

    transition:
        transform 0.2s ease,
        opacity 0.4s ease,
        box-shadow 0.2s ease;
}}

.thought:hover {{
    transform: scale(1.04);

    box-shadow:
        0 12px 28px rgba(0,0,0,0.35);
}}

.thought.dragging {{
    cursor: grabbing;

    transform:
        scale(1.08)
        rotate(2deg);

    box-shadow:
        0 18px 35px rgba(0,0,0,0.4);
}}

.thought.removed {{
    opacity: 0;
    transform:
        scale(0.2)
        translateY(80px);

    pointer-events: none;
}}


/* =====================================================
   THOUGHT POSITIONS
   These positions make the thoughts appear around
   different parts of the garden.
===================================================== */

.t1 {{
    left: 5%;
    top: 18%;
}}

.t2 {{
    left: 25%;
    top: 40%;
}}

.t3 {{
    left: 44%;
    top: 14%;
}}

.t4 {{
    right: 5%;
    top: 20%;
}}

.t5 {{
    right: 24%;
    top: 43%;
}}

.t6 {{
    left: 39%;
    bottom: 10%;
}}


/* =====================================================
   DRAG TARGET
===================================================== */

.drop-zone {{
    position: absolute;

    z-index: 30;

    right: 25px;
    bottom: 25px;

    width: 155px;
    height: 115px;

    border-radius: 22px;

    background:
        linear-gradient(
            145deg,
            #563321,
            #7d492e,
            #472719
        );

    border: 4px solid #d49b68;

    box-shadow:
        0 12px 30px rgba(0,0,0,0.45);

    display: flex;
    flex-direction: column;

    align-items: center;
    justify-content: center;

    color: white;

    transition:
        transform 0.25s ease,
        box-shadow 0.25s ease,
        background 0.25s ease;
}}

.drop-zone::before {{
    content: "";

    position: absolute;

    top: -13px;

    width: 120px;
    height: 25px;

    border-radius: 50%;

    background:
        linear-gradient(
            90deg,
            #3a2118,
            #a96643,
            #3a2118
        );

    border: 3px solid #d49b68;
}}

.drop-zone strong {{
    margin-top: 12px;

    font-size: 16px;
    letter-spacing: 1px;
}}

.drop-zone span {{
    font-size: 11px;
    margin-top: 4px;
    opacity: 0.8;
}}

.drop-zone.active {{
    transform: scale(1.12);

    box-shadow:
        0 0 25px rgba(255,220,170,0.9),
        0 18px 40px rgba(0,0,0,0.45);

    background:
        linear-gradient(
            145deg,
            #71432c,
            #a6643d,
            #55301f
        );
}}


/* =====================================================
   INSTRUCTIONS
===================================================== */

.instructions {{
    position: absolute;

    z-index: 31;

    left: 50%;
    bottom: 25px;

    transform: translateX(-50%);

    padding: 10px 20px;

    border-radius: 20px;

    color: white;

    background:
        rgba(20,30,25,0.62);

    backdrop-filter: blur(6px);

    font-size: 13px;

    text-align: center;

    pointer-events: none;
}}


/* =====================================================
   BLOOMING EFFECT
===================================================== */

.bloom-petals {{
    position: absolute;

    inset: 0;

    z-index: 40;

    pointer-events: none;

    overflow: hidden;

    opacity: 0;
}}

.garden.finished .bloom-petals {{
    opacity: 1;
}}

.petal {{
    position: absolute;

    top: -30px;

    width: 12px;
    height: 18px;

    border-radius:
        70% 30% 70% 30%;

    background:
        linear-gradient(
            135deg,
            #fff5fb,
            #f4a8d3
        );

    animation:
        fall 5s linear forwards;
}}

@keyframes fall {{

    0% {{
        transform:
            translateY(-40px)
            rotate(0deg);
        opacity: 0;
    }}

    15% {{
        opacity: 1;
    }}

    100% {{
        transform:
            translateY(720px)
            rotate(500deg);
        opacity: 0;
    }}
}}


/* =====================================================
   COMPLETION
===================================================== */

.complete-message {{
    position: absolute;

    z-index: 50;

    left: 50%;
    top: 50%;

    transform:
        translate(-50%, -50%)
        scale(0.75);

    width: min(600px, 82%);

    padding: 32px 35px;

    text-align: center;

    background:
        rgba(255,250,247,0.95);

    border-radius: 28px;

    box-shadow:
        0 25px 70px rgba(0,0,0,0.35);

    opacity: 0;

    pointer-events: none;

    transition:
        opacity 1s ease,
        transform 1s ease;
}}

.garden.finished .complete-message {{
    opacity: 1;

    transform:
        translate(-50%, -50%)
        scale(1);

    pointer-events: auto;
}}

.complete-title {{
    color: #7b3f72;

    font-size: 29px;

    font-weight: bold;

    margin-bottom: 14px;
}}

.complete-text {{
    color: #443846;

    font-size: 18px;

    line-height: 1.6;

    margin-bottom: 20px;
}}

.play-again {{
    border: none;

    padding: 12px 28px;

    border-radius: 25px;

    background:
        linear-gradient(
            135deg,
            #7b2cbf,
            #e879b9
        );

    color: white;

    font-size: 15px;

    font-weight: bold;

    cursor: pointer;

    box-shadow:
        0 8px 20px rgba(123,44,191,0.3);
}}

.play-again:hover {{
    transform: scale(1.04);
}}


/* =====================================================
   RESPONSIVE
===================================================== */

@media (max-width: 800px) {{

    .game-title {{
        font-size: 26px;
    }}

    .garden {{
        height: 580px;
    }}

    .thought {{
        width: 155px;
        font-size: 12px;
        min-height: 65px;
        padding: 10px;
    }}

    .drop-zone {{
        width: 130px;
        height: 95px;
        right: 15px;
        bottom: 15px;
    }}

    .instructions {{
        width: 45%;
        font-size: 11px;
        bottom: 18px;
    }}
}}

</style>

</head>


<body>


<div class="game-wrapper">


    <div class="game-title">
        Stress Garden
    </div>


    <div class="game-subtitle">
        Find the thoughts hiding around the garden and let them go.
    </div>


    <div class="progress-area">

        <div class="progress-text" id="progressText">
            0 of 6 thoughts released
        </div>

        <div class="progress-track">

            <div
                class="progress-fill"
                id="progressFill">
            </div>

        </div>

    </div>


    <div
        class="garden"
        id="garden"
    >


        <!-- DRY GARDEN -->

        <img
            class="garden-dry"
            id="dryGarden"
            src="data:image/png;base64,{dry_image}"
        >


        <!-- BLOOMING GARDEN -->

        <img
            class="garden-bloom"
            id="bloomGarden"
            src="data:image/png;base64,{bloom_image}"
        >


        <div class="garden-glow"></div>


        <!-- THOUGHTS -->

        <div
            class="thought t1"
            draggable="true"
            data-index="0"
        >
            {selected_thoughts[0]}
        </div>


        <div
            class="thought t2"
            draggable="true"
            data-index="1"
        >
            {selected_thoughts[1]}
        </div>


        <div
            class="thought t3"
            draggable="true"
            data-index="2"
        >
            {selected_thoughts[2]}
        </div>


        <div
            class="thought t4"
            draggable="true"
            data-index="3"
        >
            {selected_thoughts[3]}
        </div>


        <div
            class="thought t5"
            draggable="true"
            data-index="4"
        >
            {selected_thoughts[4]}
        </div>


        <div
            class="thought t6"
            draggable="true"
            data-index="5"
        >
            {selected_thoughts[5]}
        </div>


        <!-- DROP BIN -->

        <div
            class="drop-zone"
            id="dropZone"
        >

            <strong>LET IT GO</strong>

            <span>
                Release the thought
            </span>

        </div>


        <div class="instructions">
            Drag a stressful thought into the basket.
        </div>


        <!-- PETALS -->

        <div
            class="bloom-petals"
            id="bloomPetals"
        ></div>


        <!-- COMPLETION -->

        <div
            class="complete-message"
            id="completeMessage"
        >

            <div class="complete-title">
                Your garden is blooming
            </div>

            <div class="complete-text">
                You don't have to carry every thought with you.
                Take a gentle breath, give yourself a little space,
                and remember to take care of yourself.
            </div>

            <button
                class="play-again"
                onclick="playAgain()"
            >
                Play Again
            </button>

        </div>


    </div>

</div>


<script>


/* =========================================================
   GAME DATA
========================================================= */

const thoughts = {thoughts_json};

let released = 0;

const totalThoughts = thoughts.length;


/* =========================================================
   ELEMENTS
========================================================= */

const garden =
    document.getElementById("garden");

const dryGarden =
    document.getElementById("dryGarden");

const bloomGarden =
    document.getElementById("bloomGarden");

const dropZone =
    document.getElementById("dropZone");

const progressText =
    document.getElementById("progressText");

const progressFill =
    document.getElementById("progressFill");

const thoughtElements =
    document.querySelectorAll(".thought");


/* =========================================================
   PROGRESS
========================================================= */

function updateProgress() {{

    progressText.textContent =
        released +
        " of " +
        totalThoughts +
        " thoughts released";

    progressFill.style.width =
        ((released / totalThoughts) * 100) + "%";


    /*
       Gradually reveal the beautiful garden.
       The dry garden becomes less visible while
       the blooming garden becomes more visible.
    */

    const progress =
        released / totalThoughts;

    dryGarden.style.opacity =
        1 - (progress * 0.82);

    bloomGarden.style.opacity =
        progress * 0.90;


    if (released > 0) {{
        garden.classList.add("glowing");
    }}
}}


/* =========================================================
   DRAG START
========================================================= */

thoughtElements.forEach(function(thought) {{

    thought.addEventListener(
        "dragstart",
        function(event) {{

            event.dataTransfer.setData(
                "text/plain",
                thought.dataset.index
            );

            thought.classList.add("dragging");

        }}
    );


    thought.addEventListener(
        "dragend",
        function() {{

            thought.classList.remove("dragging");

            dropZone.classList.remove("active");

        }}
    );

}});


/* =========================================================
   DROP ZONE
========================================================= */

dropZone.addEventListener(
    "dragover",
    function(event) {{

        event.preventDefault();

        dropZone.classList.add("active");

    }}
);


dropZone.addEventListener(
    "dragleave",
    function() {{

        dropZone.classList.remove("active");

    }}
);


dropZone.addEventListener(
    "drop",
    function(event) {{

        event.preventDefault();

        dropZone.classList.remove("active");


        const index =
            event.dataTransfer.getData(
                "text/plain"
            );


        const thought =
            document.querySelector(
                '.thought[data-index="' +
                index +
                '"]'
            );


        if (!thought) {{
            return;
        }}


        /*
           Prevent the same thought from
           being counted more than once.
        */

        if (
            thought.classList.contains("removed")
        ) {{
            return;
        }}


        thought.classList.add("removed");


        released += 1;

        updateProgress();


        /*
           Small visual glow after each
           thought is released.
        */

        garden.style.filter =
            "brightness(1.06)";

        setTimeout(function() {{
            garden.style.filter =
                "brightness(1)";
        }}, 450);


        /*
           When all thoughts are gone,
           complete the garden.
        */

        if (released === totalThoughts) {{

            setTimeout(
                finishGarden,
                900
            );

        }}

    }}
);


/* =========================================================
   FINISH GARDEN
========================================================= */

function finishGarden() {{

    garden.classList.add("finished");


    dryGarden.style.opacity = "0";

    bloomGarden.style.opacity = "1";


    /*
       Create falling flower petals.
    */

    const petals =
        document.getElementById(
            "bloomPetals"
        );


    for (
        let i = 0;
        i < 35;
        i++
    ) {{

        const petal =
            document.createElement(
                "div"
            );


        petal.className = "petal";


        petal.style.left =
            Math.random() * 100 + "%";


        petal.style.animationDelay =
            Math.random() * 2.5 + "s";


        petal.style.animationDuration =
            (4 + Math.random() * 3) + "s";


        petals.appendChild(petal);

    }}

}}


/* =========================================================
   PLAY AGAIN
========================================================= */

function playAgain() {{

    /*
       Reloading the iframe gives the user
       a fresh random set of thoughts.
    */

    window.location.reload();

}}


/* =========================================================
   INITIAL STATE
========================================================= */

updateProgress();

</script>


</body>

</html>
"""


# =========================================================
# DISPLAY GAME
# =========================================================

components.html(
    game_html,
    height=760,
    scrolling=False
)