import streamlit as st
from pathlib import Path
import json
import joblib
import pandas as pd


# =========================================================
# PAGE SETTINGS
# =========================================================

st.set_page_config(
    page_title="MindBloom - Results",
    page_icon="🌸",
    layout="wide"
)


# =========================================================
# PATHS
# =========================================================

# 02_result.py is inside:
# app/pages/02_result.py

# Therefore BASE_DIR = app folder
BASE_DIR = Path(__file__).resolve().parent.parent

# Assets are inside:
# app/assets/
ASSETS_DIR = BASE_DIR / "assets"

# Data is outside app:
# project/data/
DATA_DIR = BASE_DIR.parent / "data"

# Model is outside app:
# project/model/
MODEL_DIR = BASE_DIR.parent / "model"


ANSWERS_FILE = DATA_DIR / "latest_assessment.json"
MODEL_FILE = MODEL_DIR / "stress_model.pkl"


# Result videos
LOW_VIDEO = ASSETS_DIR / "low_stress.mp4"
MODERATE_VIDEO = ASSETS_DIR / "moderate_stress.mp4"
HIGH_VIDEO = ASSETS_DIR / "high_stress.mp4"


# =========================================================
# STYLE
# =========================================================

st.markdown(
    """
    <style>

    .stApp {
        background-color: #071a38;
    }

    .title {
        font-size: 36px;
        font-weight: bold;
        color: white;
    }

    .subtitle {
        font-size: 19px;
        color: #e7a6ff;
    }

    .result-title {
        font-size: 44px;
        font-weight: bold;
        color: white;
    }

    .result-message {
        font-size: 19px;
        color: white;
        line-height: 1.6;
    }

    </style>
    """,
    unsafe_allow_html=True
)


# =========================================================
# THE EXACT 12 FEATURES USED BY OUR MODEL
# =========================================================

FEATURES = [
    "anxiety_level",
    "self_esteem",
    "mental_health_history",
    "depression",
    "sleep_quality",
    "academic_performance",
    "study_load",
    "future_career_concerns",
    "social_support",
    "peer_pressure",
    "headache",
    "bullying"
]


# =========================================================
# CHECK ANSWERS FILE
# =========================================================

if not ANSWERS_FILE.exists():

    st.error(
        "Your assessment answers were not found. "
        "Please complete the questionnaire again."
    )

    st.stop()


# =========================================================
# READ ANSWERS
# =========================================================

try:

    with open(
        ANSWERS_FILE,
        "r",
        encoding="utf-8"
    ) as file:

        answers = json.load(file)

except Exception:

    st.error(
        "There was a problem reading your assessment answers."
    )

    st.stop()


# =========================================================
# CHECK THAT ALL 12 ANSWERS EXIST
# =========================================================

missing = [
    feature
    for feature in FEATURES
    if feature not in answers
]


if missing:

    st.error(
        "Some assessment answers are missing."
    )

    st.write("Missing answers:")

    for feature in missing:
        st.write(f"- {feature}")

    st.warning(
        "Please complete all four sections again."
    )

    st.stop()


# =========================================================
# PREPARE THE 12 ANSWERS FOR THE MODEL
# =========================================================

try:

    input_data = {}

    for feature in FEATURES:

        input_data[feature] = float(
            answers[feature]
        )

    input_df = pd.DataFrame(
        [input_data],
        columns=FEATURES
    )

except Exception:

    st.error(
        "The assessment answers contain invalid values."
    )

    st.stop()


# =========================================================
# CHECK MODEL FILE
# =========================================================

if not MODEL_FILE.exists():

    st.error(
        "The Random Forest model was not found."
    )

    st.write(
        "Expected model location:"
    )

    st.code(str(MODEL_FILE))

    st.stop()


# =========================================================
# LOAD RANDOM FOREST MODEL
# =========================================================

try:

    model = joblib.load(
        MODEL_FILE
    )

except Exception as error:

    st.error(
        "There was a problem loading the Random Forest model."
    )

    st.write(error)

    st.stop()


# =========================================================
# VERIFY MODEL FEATURES
# =========================================================

try:

    model_features = list(
        model.feature_names_in_
    )

except AttributeError:

    st.error(
        "The saved model does not contain feature names."
    )

    st.stop()


if model_features != FEATURES:

    st.error(
        "The model features do not match the questionnaire."
    )

    st.write("Model features:")

    st.write(model_features)

    st.write("Expected features:")

    st.write(FEATURES)

    st.stop()


# =========================================================
# RANDOM FOREST PREDICTION
# =========================================================

try:

    prediction = model.predict(
        input_df
    )[0]

    prediction = int(prediction)

except Exception as error:

    st.error(
        "The Random Forest could not predict the stress level."
    )

    st.write(error)

    st.stop()


# =========================================================
# MODEL CONFIDENCE
# =========================================================

try:

    probabilities = model.predict_proba(
        input_df
    )[0]

    confidence = max(probabilities) * 100

except Exception:

    confidence = None


# =========================================================
# CONVERT PREDICTION INTO STRESS LEVEL
# =========================================================

if prediction == 0:

    stress_level = "Low"

    result_title = "Low Stress 🌿"

    result_message = (
        "Your responses suggest that your current "
        "stress level is relatively low."
    )

    result_video = LOW_VIDEO


elif prediction == 1:

    stress_level = "Moderate"

    result_title = "Moderate Stress 🌸"

    result_message = (
        "Your responses suggest that you may be "
        "experiencing a moderate amount of stress."
    )

    result_video = MODERATE_VIDEO


elif prediction == 2:

    stress_level = "High"

    result_title = "High Stress 💗"

    result_message = (
        "Your responses suggest that you may be "
        "experiencing a higher level of stress "
        "at the moment."
    )

    result_video = HIGH_VIDEO


else:

    st.error(
        "The model returned an unexpected stress level."
    )

    st.stop()


# =========================================================
# RESULT PAGE LAYOUT
# =========================================================

left, right = st.columns(
    [1.15, 3.85]
)


# =========================================================
# LEFT SIDE — RESULT VIDEO
# =========================================================

with left:

    st.markdown(
        "<br><br>",
        unsafe_allow_html=True
    )

    if result_video.exists():

        st.video(
            str(result_video),
            autoplay=True,
            loop=True,
            muted=True
        )

    else:

        st.warning(
            "Result video not found."
        )


# =========================================================
# RIGHT SIDE — RESULT
# =========================================================

with right:

    st.markdown(
        """
        <div class="title">
            🌸 Your MindBloom Result
        </div>
        """,
        unsafe_allow_html=True
    )

    st.markdown(
        """
        <div class="subtitle">
            Thank you for completing the assessment 💗
        </div>
        """,
        unsafe_allow_html=True
    )

    st.divider()


    # Result heading

    st.markdown(
        f"""
        <div class="result-title">
            {result_title}
        </div>
        """,
        unsafe_allow_html=True
    )


    st.markdown(
        "<br>",
        unsafe_allow_html=True
    )


    # Result message

    st.markdown(
        f"""
        <div class="result-message">
            {result_message}
        </div>
        """,
        unsafe_allow_html=True
    )


    st.markdown(
        "<br>",
        unsafe_allow_html=True
    )


    # Model confidence

    if confidence is not None:

        st.info(
            f"🌸 Model prediction confidence: "
            f"{confidence:.1f}%"
        )


    # Disclaimer

    st.warning(
        "🌷 This system provides awareness and general "
        "wellbeing suggestions. It is not a medical "
        "diagnosis and does not replace professional help."
    )


# =========================================================
# TIPS SECTION
# =========================================================

st.markdown(
    "<br><br>",
    unsafe_allow_html=True
)


st.markdown(
    """
    <div style="
        font-size:25px;
        font-weight:bold;
        color:white;
        text-align:center;
    ">
        Would you like some tips to help manage your stress? 💗
    </div>
    """,
    unsafe_allow_html=True
)


st.markdown(
    """
    <div style="
        font-size:17px;
        color:#e7a6ff;
        text-align:center;
    ">
        We can show you simple wellbeing suggestions.
    </div>
    """,
    unsafe_allow_html=True
)


st.markdown(
    "<br>",
    unsafe_allow_html=True
)


# =========================================================
# YES / NO BUTTONS
# =========================================================

col1, col2 = st.columns(2)


# =========================================================
# YES BUTTON
# =========================================================

with col1:

    if st.button(
        "Yes, show me tips 🌸",
        use_container_width=True
    ):

        st.switch_page(
    "pages/03_support.py"
)


# =========================================================
# NO BUTTON
# =========================================================

with col2:

    if st.button(
        "No, thank you",
        use_container_width=True
    ):

        st.success(
            "Thank you for using MindBloom. "
            "Take care of yourself! 🌷"
        )