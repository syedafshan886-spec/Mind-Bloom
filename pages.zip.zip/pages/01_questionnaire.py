import streamlit as st
from pathlib import Path
import time
import json


# =========================================================
# PAGE SETTINGS
# =========================================================

st.set_page_config(
    page_title="MindBloom - Assessment",
    page_icon="🌸",
    layout="wide"
)


# =========================================================
# PATHS
# =========================================================

# questionnaire.py is inside:
# app/pages/questionnaire.py

# Therefore:
# BASE_DIR = app/

BASE_DIR = Path(__file__).resolve().parent.parent

ASSETS_DIR = BASE_DIR / "assets"

# Data folder:
# project/data/

DATA_DIR = BASE_DIR.parent / "data"
DATA_DIR.mkdir(exist_ok=True)

ANSWERS_FILE = DATA_DIR / "latest_assessment.json"


# =========================================================
# VIDEOS
# =========================================================

VIDEO_1 = ASSETS_DIR / "section1_video.mp4"
VIDEO_2 = ASSETS_DIR / "section2_video.mp4"
VIDEO_3 = ASSETS_DIR / "section3_video.mp4"
VIDEO_4 = ASSETS_DIR / "section4_video.mp4"

LOADING_VIDEO = ASSETS_DIR / "loading_video.mp4"


# =========================================================
# EXACT 12 MODEL FEATURES
# =========================================================

FEATURES = [
    "anxiety_level",
    "self_esteem",
    "mental_health_history",
    "depression",
    "sleep_quality",
    "academic_performance",
    "study_load",
    "future_career_concerns",
    "social_support",
    "peer_pressure",
    "headache",
    "bullying"
]


# =========================================================
# SESSION STATE
# =========================================================

if "section" not in st.session_state:
    st.session_state.section = 1


# =========================================================
# DEFAULT VALUES
# =========================================================

defaults = {
    "anxiety_level": 0,
    "self_esteem": 30,
    "mental_health_history": 0,

    "depression": 0,
    "sleep_quality": 5,
    "academic_performance": 5,

    "study_load": 0,
    "future_career_concerns": 0,
    "social_support": 5,

    "peer_pressure": 0,
    "headache": 0,
    "bullying": 0
}


for key, value in defaults.items():

    if key not in st.session_state:
        st.session_state[key] = value


# =========================================================
# STYLE
# =========================================================

st.markdown(
    """
    <style>

    .stApp {
        background-color: #071a38;
    }

    .title {
        font-size: 34px;
        font-weight: bold;
        color: white;
    }

    .subtitle {
        font-size: 18px;
        color: #e7a6ff;
    }

    .section {
        font-size: 24px;
        font-weight: bold;
        color: white;
        margin-top: 10px;
    }

    .question {
        font-size: 20px;
        font-weight: bold;
        color: white;
        margin-top: 20px;
    }

    .loading-title {
        font-size: 34px;
        font-weight: bold;
        color: white;
        text-align: center;
    }

    .loading-subtitle {
        font-size: 20px;
        color: #e7a6ff;
        text-align: center;
    }

    </style>
    """,
    unsafe_allow_html=True
)


# =========================================================
# LOADING SCREEN
# =========================================================

if st.session_state.section == 5:

    st.markdown(
        "<br><br>",
        unsafe_allow_html=True
    )

    st.markdown(
        """
        <div class="loading-title">
            🌸 Thank You for Completing the Assessment!
        </div>
        """,
        unsafe_allow_html=True
    )

    st.markdown(
        """
        <div class="loading-subtitle">
            We are loading your result... 💗
        </div>
        """,
        unsafe_allow_html=True
    )

    st.divider()

    if LOADING_VIDEO.exists():

        st.video(
            str(LOADING_VIDEO),
            autoplay=True,
            loop=False,
            muted=True
        )

    else:

        st.info(
            "🌸 Preparing your MindBloom result..."
        )

    # FIX: was time.sleep(5) — increased to match the
    # actual ~10 second length of loading_video.mp4 so
    # the video finishes playing before switching pages.
    time.sleep(10)

    # FIX: reset section back to 1 so that if the user
    # retakes the assessment later in the same browser
    # session, st.session_state.section does not keep
    # climbing past 4 and break the progress bar
    # (st.progress only accepts 0-100, i.e. section 0-4).
    st.session_state.section = 1

    st.switch_page("pages/02_result.py")
    st.stop()


# =========================================================
# MAIN LAYOUT
# =========================================================

left, right = st.columns([1, 4])


# =========================================================
# LEFT SIDE — VIDEO
# =========================================================

with left:

    st.markdown(
        "<br><br>",
        unsafe_allow_html=True
    )

    if st.session_state.section == 1:

        if VIDEO_1.exists():

            st.video(
                str(VIDEO_1),
                autoplay=True,
                loop=True,
                muted=True
            )

        else:

            st.warning("Section 1 video not found.")


    elif st.session_state.section == 2:

        if VIDEO_2.exists():

            st.video(
                str(VIDEO_2),
                autoplay=True,
                loop=True,
                muted=True
            )

        else:

            st.warning("Section 2 video not found.")


    elif st.session_state.section == 3:

        if VIDEO_3.exists():

            st.video(
                str(VIDEO_3),
                autoplay=True,
                loop=True,
                muted=True
            )

        else:

            st.warning("Section 3 video not found.")


    elif st.session_state.section == 4:

        if VIDEO_4.exists():

            st.video(
                str(VIDEO_4),
                autoplay=True,
                loop=True,
                muted=True
            )

        else:

            st.warning("Section 4 video not found.")


    st.markdown(
        """
        <div style="
            text-align:center;
            color:#FFD6E8;
            font-size:15px;
            margin-top:10px;
        ">
        🌸 You're doing great!<br>
        Take your time.
        </div>
        """,
        unsafe_allow_html=True
    )


# =========================================================
# RIGHT SIDE
# =========================================================

with right:

    # -----------------------------------------------------
    # PROGRESS
    # -----------------------------------------------------

    # FIX: clamp to 100 so st.progress() never crashes,
    # even if st.session_state.section is ever greater
    # than 4 for any reason.
    progress_value = min(st.session_state.section * 25, 100)

    st.progress(progress_value)


    # -----------------------------------------------------
    # TITLE
    # -----------------------------------------------------

    st.markdown(
        """
        <div class="title">
            🌸 Stress & Wellbeing Assessment
        </div>
        """,
        unsafe_allow_html=True
    )


    st.markdown(
        """
        <div class="subtitle">
            Let's understand how you're feeling today 💗
        </div>
        """,
        unsafe_allow_html=True
    )


    st.write(
        "Please answer the following questions honestly."
    )

    st.divider()


    # =====================================================
    # SECTION 1
    # =====================================================

    if st.session_state.section == 1:

        st.markdown("📄 **Section 1 of 4**")

        st.success(
            "🌷 You're doing great! Answer honestly. "
            "There are no right or wrong answers."
        )

        st.markdown(
            """
            <div class="section">
                📄 Section 1: Emotional Wellbeing
            </div>
            """,
            unsafe_allow_html=True
        )

        st.info(
            "⭐ Every small step toward understanding yourself "
            "is a step toward wellbeing."
        )


        # -------------------------------------------------
        # ANXIETY
        # -------------------------------------------------

        st.markdown(
            """
            <div class="question">
                🌸 How would you rate your anxiety level?
            </div>
            """,
            unsafe_allow_html=True
        )

        st.slider(
            "0 = Very Low | 21 = Very High",
            min_value=0,
            max_value=21,
            step=1,
            key="anxiety_level"
        )


        # -------------------------------------------------
        # SELF ESTEEM
        # -------------------------------------------------

        st.markdown(
            """
            <div class="question">
                💗 How would you rate your self-esteem?
            </div>
            """,
            unsafe_allow_html=True
        )

        st.slider(
            "0 = Very Low | 30 = Very High",
            min_value=0,
            max_value=30,
            step=1,
            key="self_esteem"
        )


        # -------------------------------------------------
        # MENTAL HEALTH HISTORY
        # -------------------------------------------------

        st.markdown(
            """
            <div class="question">
                🧠 Do you have a history of mental health concerns?
            </div>
            """,
            unsafe_allow_html=True
        )

        st.slider(
            "0 = No | 1 = Yes",
            min_value=0,
            max_value=1,
            step=1,
            key="mental_health_history"
        )


        st.markdown("<br>", unsafe_allow_html=True)


        if st.button(
            "Next ➜",
            key="section1_next",
            use_container_width=True
        ):

            st.session_state.section = 2
            st.rerun()


    # =====================================================
    # SECTION 2
    # =====================================================

    elif st.session_state.section == 2:

        st.markdown("📄 **Section 2 of 4**")

        st.success(
            "🌷 You're doing great! Let's explore your "
            "mental, physical and academic wellbeing."
        )

        st.markdown(
            """
            <div class="section">
                📚 Section 2: Mental & Academic Wellbeing
            </div>
            """,
            unsafe_allow_html=True
        )

        st.info(
            "💙 Your mental wellbeing, sleep and academic "
            "experience can affect how you feel."
        )


        # -------------------------------------------------
        # DEPRESSION
        # -------------------------------------------------

        st.markdown(
            """
            <div class="question">
                🌧️ How would you rate your current feelings of sadness or low mood?
            </div>
            """,
            unsafe_allow_html=True
        )

        st.slider(
            "0 = Very Low | 27 = Very High",
            min_value=0,
            max_value=27,
            step=1,
            key="depression"
        )


        # -------------------------------------------------
        # SLEEP QUALITY
        # -------------------------------------------------

        st.markdown(
            """
            <div class="question">
                🌙 How would you rate your sleep quality?
            </div>
            """,
            unsafe_allow_html=True
        )

        st.slider(
            "0 = Very Poor | 5 = Excellent",
            min_value=0,
            max_value=5,
            step=1,
            key="sleep_quality"
        )


        # -------------------------------------------------
        # ACADEMIC PERFORMANCE
        # -------------------------------------------------

        st.markdown(
            """
            <div class="question">
                📚 How would you rate your academic performance?
            </div>
            """,
            unsafe_allow_html=True
        )

        st.slider(
            "0 = Very Low | 5 = Very High",
            min_value=0,
            max_value=5,
            step=1,
            key="academic_performance"
        )


        st.markdown("<br>", unsafe_allow_html=True)


        if st.button(
            "Next ➜",
            key="section2_next",
            use_container_width=True
        ):

            st.session_state.section = 3
            st.rerun()


    # =====================================================
    # SECTION 3
    # =====================================================

    elif st.session_state.section == 3:

        st.markdown("📄 **Section 3 of 4**")

        st.success(
            "🌷 You're doing great! Let's understand your "
            "academic and social environment."
        )

        st.markdown(
            """
            <div class="section">
                🌿 Section 3: Academic & Social Wellbeing
            </div>
            """,
            unsafe_allow_html=True
        )

        st.info(
            "💚 Your workload, future concerns and social "
            "support can influence your wellbeing."
        )


        # -------------------------------------------------
        # STUDY LOAD
        # -------------------------------------------------

        st.markdown(
            """
            <div class="question">
                📖 How would you rate your current study workload?
            </div>
            """,
            unsafe_allow_html=True
        )

        st.slider(
            "0 = Very Low | 5 = Very High",
            min_value=0,
            max_value=5,
            step=1,
            key="study_load"
        )


        # -------------------------------------------------
        # FUTURE CAREER CONCERNS
        # -------------------------------------------------

        st.markdown(
            """
            <div class="question">
                🎓 How concerned are you about your future career?
            </div>
            """,
            unsafe_allow_html=True
        )

        st.slider(
            "0 = Not Concerned | 5 = Very Concerned",
            min_value=0,
            max_value=5,
            step=1,
            key="future_career_concerns"
        )


        # -------------------------------------------------
        # SOCIAL SUPPORT
        # -------------------------------------------------

        st.markdown(
            """
            <div class="question">
                👥 How much support do you receive from friends and family?
            </div>
            """,
            unsafe_allow_html=True
        )

        st.slider(
            "0 = No Support | 5 = Very Strong Support",
            min_value=0,
            max_value=5,
            step=1,
            key="social_support"
        )


        st.markdown("<br>", unsafe_allow_html=True)


        if st.button(
            "Next ➜",
            key="section3_next",
            use_container_width=True
        ):

            st.session_state.section = 4
            st.rerun()


    # =====================================================
    # SECTION 4
    # =====================================================

    elif st.session_state.section == 4:

        st.markdown("📄 **Section 4 of 4**")

        st.success(
            "🌷 Almost there! This is the final section."
        )

        st.markdown(
            """
            <div class="section">
                🌸 Section 4: Social & Physical Wellbeing
            </div>
            """,
            unsafe_allow_html=True
        )

        st.info(
            "💗 Take your time and answer each question honestly."
        )


        # -------------------------------------------------
        # PEER PRESSURE
        # -------------------------------------------------

        st.markdown(
            """
            <div class="question">
                👥 How much peer pressure do you experience?
            </div>
            """,
            unsafe_allow_html=True
        )

        st.slider(
            "0 = Very Low | 5 = Very High",
            min_value=0,
            max_value=5,
            step=1,
            key="peer_pressure"
        )


        # -------------------------------------------------
        # HEADACHE
        # -------------------------------------------------

        st.markdown(
            """
            <div class="question">
                🤕 How frequently do you experience headaches?
            </div>
            """,
            unsafe_allow_html=True
        )

        st.slider(
            "0 = Never | 5 = Very Frequently",
            min_value=0,
            max_value=5,
            step=1,
            key="headache"
        )


        # -------------------------------------------------
        # BULLYING
        # -------------------------------------------------

        st.markdown(
            """
            <div class="question">
                🛡️ How much bullying or unwanted negative treatment do you experience?
            </div>
            """,
            unsafe_allow_html=True
        )

        st.slider(
            "0 = None | 5 = Very High",
            min_value=0,
            max_value=5,
            step=1,
            key="bullying"
        )


        st.markdown("<br>", unsafe_allow_html=True)


        # =================================================
        # FINISH
        # =================================================

        if st.button(
            "Finish ✓",
            key="finish_button",
            use_container_width=True
        ):

            # -------------------------------------------------
            # SAVE EXACTLY THE 12 MODEL FEATURES
            # -------------------------------------------------

            final_answers = {

                "anxiety_level":
                    int(st.session_state.anxiety_level),

                "self_esteem":
                    int(st.session_state.self_esteem),

                "mental_health_history":
                    int(st.session_state.mental_health_history),

                "depression":
                    int(st.session_state.depression),

                "sleep_quality":
                    int(st.session_state.sleep_quality),

                "academic_performance":
                    int(st.session_state.academic_performance),

                "study_load":
                    int(st.session_state.study_load),

                "future_career_concerns":
                    int(st.session_state.future_career_concerns),

                "social_support":
                    int(st.session_state.social_support),

                "peer_pressure":
                    int(st.session_state.peer_pressure),

                "headache":
                    int(st.session_state.headache),

                "bullying":
                    int(st.session_state.bullying)
            }


            # -------------------------------------------------
            # SAVE JSON
            # -------------------------------------------------

            with open(
                ANSWERS_FILE,
                "w",
                encoding="utf-8"
            ) as file:

                json.dump(
                    final_answers,
                    file,
                    indent=4
                )


            # -------------------------------------------------
            # GO TO LOADING SCREEN
            # -------------------------------------------------

            st.session_state.section = 5

            st.rerun()